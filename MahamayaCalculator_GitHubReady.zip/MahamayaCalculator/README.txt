
MahamayaCalculator - Basic Android Studio project (debug)

How to build APK:
1. Open Android Studio.
2. Choose 'Open' and select the folder 'MahamayaCalculator' (the folder that contains 'app').
3. Let Android Studio sync the project. If it asks to create Gradle files or SDK, follow prompts and install recommended SDK.
4. File -> Sync Project with Gradle Files (if needed).
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. After build completes, click 'Locate' in the bottom-right notification to find the generated APK.

Notes:
- This is a minimal template. If Android Studio prompts for Gradle or plugin updates, accept defaults.
- If you want, share the generated APK file with me and I will help iterate.
